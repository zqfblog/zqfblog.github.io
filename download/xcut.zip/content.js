(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const contentJs_1 = require("./lib/contentJs");
var contentJs = new contentJs_1.ContentJs();
chrome.runtime.onMessage.addListener(function (req, sender, res) {
    //debugger;
    if (req.msg === 'init') {
        contentJs.init();
    }
    else if (req.msg === 'cancle') {
        contentJs.cancle();
    }
    return true;
});

},{"./lib/contentJs":2}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ContentJs {
    constructor() {
        this.fakeImgId = 'fake-image';
        this.init = () => {
            debugger;
            let fakeImg = document.querySelector('#' + this.fakeImgId);
            if (!fakeImg) {
                this.addFakeImage(() => {
                    chrome.runtime.sendMessage({ msg: 'init-ok' }, (res) => {
                        if (res) {
                            this.jCropSetting(() => {
                                this.showJcropHolder(true);
                            });
                        }
                    });
                });
            }
            else {
                chrome.runtime.sendMessage({ msg: 'init-ok' }, (res) => {
                    if (res) {
                        this.showJcropHolder(true);
                    }
                });
            }
        };
        this.cancle = () => {
            //this.jcrop.release();
            this.showJcropHolder(false);
            this.selection = null;
        };
        this.addFakeImage = (done) => {
            let fakeImage = new Image();
            fakeImage.id = this.fakeImgId;
            fakeImage.src = chrome.runtime.getURL('/assets/images/pixel.png');
            fakeImage.onload = () => {
                document.body.append(fakeImage);
                done();
            };
        };
        this.jCropSetting = (done) => {
            var tmpThis = this;
            $('#' + this.fakeImgId).Jcrop({
                bgColor: 'none',
                onSelect: (e) => {
                    this.selection = e;
                    this.capture();
                },
                onChange: (e) => {
                    this.selection = e;
                },
                onRelease: (e) => {
                    this.selection = null;
                }
            }, function () {
                tmpThis.jcrop = this;
                $('.jcrop-hline, .jcrop-vline').css({
                    backgroundImage: `url(${chrome.runtime.getURL('/assets/images/Jcrop.gif')})`
                });
                done && done();
            });
        };
        this.showJcropHolder = (actiove) => {
            $('.jcrop-holder')[actiove ? 'show' : 'hide']();
        };
        this.capture = () => {
            if (this.selection) {
                this.showJcropHolder(false);
                if (this.timeout) {
                    clearTimeout(this.timeout);
                }
                this.timeout = setTimeout(() => {
                    var msg = { msg: 'capture', area: this.selection, dpr: devicePixelRatio };
                    this.jcrop.release();
                    chrome.runtime.sendMessage(msg, (res) => {
                        this.selection = null;
                        //this.save(res.image, 'png', 'file');
                    });
                }, 100);
            }
        };
    }
}
exports.ContentJs = ContentJs;

},{}]},{},[1]);
