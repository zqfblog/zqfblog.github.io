(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const backgroundJs_1 = require("./lib/backgroundJs");
var backgroundJs = new backgroundJs_1.BackGroundJs();
backgroundJs.doit();

},{"./lib/backgroundJs":2}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class BackGroundJs {
    constructor() {
        this.isPopup = false;
        this.doit = () => {
            chrome.tabs.onCreated.addListener(this.checkTabStatus);
            chrome.tabs.onUpdated.addListener(this.checkTabStatus);
            chrome.tabs.onActivated.addListener(this.checkTabStatus);
            chrome.browserAction.onClicked.addListener((tab) => {
                if (!this.isPopup) {
                    this.inject(tab);
                }
            });
            chrome.runtime.onMessage.addListener((req, sender, res) => {
                this.doMessage(req, sender, res);
                return true;
            });
        };
        this.doMessage = (req, sender, res) => {
            if (req.msg === 'init-ok') {
                chrome.tabs.insertCSS(sender.tab.id, { file: 'vendor/jquery.Jcrop.min.css', runAt: 'document_start' }, () => {
                    chrome.tabs.insertCSS(sender.tab.id, { file: 'assets/css/content.css', runAt: 'document_start' }, () => {
                        chrome.tabs.executeScript(sender.tab.id, { file: 'vendor/jquery.min.js', runAt: 'document_start' }, () => {
                            chrome.tabs.executeScript(sender.tab.id, { file: 'vendor/jquery.Jcrop.min.js', runAt: 'document_start' }, () => {
                                res({ msg: 'inject-ok' });
                            });
                        });
                    });
                });
            }
            else if (req.msg === 'capture') {
                chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: 'png', quality: 100 }, (image) => {
                    // image is base64
                    this.crop(image, req.area, req.dpr, 1, 'png', (cropped) => {
                        chrome.storage.local.set({ 'imageData': cropped }, () => {
                            chrome.tabs.create({ url: 'editor.html' });
                        });
                        res({ msg: 'image', image: cropped });
                        chrome.browserAction.setBadgeText({ text: '' });
                    });
                });
            }
            //return true
        };
        this.crop = (image, area, dpr, preserve, format, done) => {
            var top = area.y * dpr;
            var left = area.x * dpr;
            var width = area.w * dpr;
            var height = area.h * dpr;
            var w = (dpr !== 1 && preserve) ? width : area.w;
            var h = (dpr !== 1 && preserve) ? height : area.h;
            var canvas = null;
            if (!canvas) {
                canvas = document.createElement('canvas');
                document.body.appendChild(canvas);
            }
            canvas.width = w;
            canvas.height = h;
            var img = new Image();
            img.src = image;
            img.onload = () => {
                var context = canvas.getContext('2d');
                context.drawImage(img, left, top, width, height, 0, 0, w, h);
                var cropped = canvas.toDataURL(`image/${format}`);
                done(cropped);
            };
        };
    }
    inject(tab) {
        chrome.tabs.executeScript(tab.id, { file: 'content.js', runAt: 'document_start' }, () => {
            //if (Utility.doLastError()) {
            chrome.tabs.sendMessage(tab.id, { msg: 'init' });
            chrome.browserAction.setBadgeText({ text: 'ON' });
            //}
        });
    }
    checkTabStatus() {
        chrome.browserAction.setBadgeText({ text: '' });
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs.length > 0 && /http(s?):\/\//.test(tabs[0].url.toLowerCase())) {
                this.isPopup = false;
                chrome.browserAction.setPopup({ popup: '' });
            }
            else {
                this.isPopup = true;
                chrome.browserAction.setPopup({ popup: 'alter.html' });
            }
        });
    }
}
exports.BackGroundJs = BackGroundJs;

},{}]},{},[1]);
