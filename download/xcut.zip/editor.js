(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const freeDrawing_1 = __importDefault(require("./lib/freeDrawing"));
const utility_1 = require("./lib/utility");
document.getElementById('editor-desc').innerHTML = chrome.i18n.getMessage('editorDesc');
document.getElementById('editor-save').innerHTML = chrome.i18n.getMessage('editorSave');
document.getElementById('editor-copyright').innerHTML = chrome.i18n.getMessage('editorCopyright');
document.getElementById('editor-undo').setAttribute('title', chrome.i18n.getMessage('editorUndo'));
document.getElementById('editor-redo').setAttribute('title', chrome.i18n.getMessage('editorRedo'));
var fileName = (format) => {
    return 'xCut-' + formatDate('yyyy-MM-dd-hhmmss', new Date()) + '.' + format;
};
var formatDate = (fmt, date) => {
    var o = {
        "M+": date.getMonth() + 1,
        "d+": date.getDate(),
        "h+": date.getHours(),
        "m+": date.getMinutes(),
        "s+": date.getSeconds(),
        "q+": Math.floor((date.getMonth() + 3) / 3),
        "S": date.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};
chrome.storage.local.get('imageData', (res) => {
    var imag = new Image();
    imag.src = res.imageData;
    imag.onload = () => {
        var cfd = new freeDrawing_1.default({
            elementId: 'canvas',
            width: imag.width,
            height: imag.height,
        });
        cfd.context.drawImage(imag, 0, 0);
        cfd.storeSnapshot();
        cfd.setLineWidth(2);
        cfd.setStrokeColor([255, 0, 0]);
        document.getElementById('editor-undo').onclick = (el) => {
            if (cfd.snapshots.length > 2) {
                cfd.undo();
            }
        };
        document.getElementById('editor-redo').onclick = () => {
            cfd.redo();
        };
        document.getElementById('editor-save').onclick = () => {
            chrome.downloads.download({ url: cfd.save(), saveAs: true, filename: fileName('png') });
        };
        var colorBtns = document.querySelectorAll('.colorBtn');
        for (var i = 0; i < colorBtns.length; i++) {
            colorBtns[i].onclick = function (ev) {
                var color = ev.target.getAttribute('color');
                cfd.setStrokeColor(utility_1.Utility.hex2RGB(color));
            };
        }
    };
});

},{"./lib/freeDrawing":2,"./lib/utility":3}],2:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AllowedEvents;
(function (AllowedEvents) {
    AllowedEvents["redraw"] = "redraw";
    AllowedEvents["fill"] = "fill";
    AllowedEvents["mouseup"] = "mouseup";
    AllowedEvents["mousedown"] = "mousedown";
    AllowedEvents["mouseenter"] = "mouseenter";
    AllowedEvents["mouseleave"] = "mouseleave";
})(AllowedEvents = exports.AllowedEvents || (exports.AllowedEvents = {}));
class freeDrawing {
    constructor(params) {
        const { elementId, width, height, backgroundColor = [255, 255, 255], lineWidth = 5, strokeColor = [0, 0, 0], disabled, showWarnings = false, maxSnapshots = 10, } = params;
        this.requiredParam(params, 'elementId');
        this.requiredParam(params, 'width');
        this.requiredParam(params, 'height');
        this.elementId = elementId;
        this.canvasNode = document.getElementById(this.elementId);
        if (this.canvasNode instanceof HTMLCanvasElement) {
            this.canvas = this.canvasNode;
        }
        else if (this.canvasNode instanceof HTMLElement) {
            const newCanvas = document.createElement('canvas');
            this.canvasNode.appendChild(newCanvas);
            this.canvas = newCanvas;
        }
        else {
            throw new Error(`No element found with following id: ${this.elementId}`);
        }
        this.context = this.canvas.getContext('2d');
        this.width = width;
        this.height = height;
        this.maxSnapshots = maxSnapshots;
        this.snapshots = [];
        this.undos = [];
        this.positions = [];
        this.leftCanvasDrawing = false; // to check if user left the canvas drawing, on mouseover resume drawing
        this.isDrawing = false;
        this.isDrawingModeEnabled = true;
        this.imageRestored = false;
        this.lineWidth = lineWidth;
        this.strokeColor = this.toValidColor(strokeColor);
        this.bucketToolColor = this.toValidColor(strokeColor);
        this.bucketToolTolerance = 0;
        this.isBucketToolEnabled = false;
        this.listenersList = [
            'mouseDown',
            'mouseMove',
            'mouseLeave',
            'mouseUp',
            'touchStart',
            'touchMove',
            'touchEnd',
        ];
        this.allowedEvents = this.getAllowedEvents();
        this.redrawCounter = 0;
        this.dispatchEventsOnceEvery = 0; // this may become something like: [{event, counter}]
        // initialize events
        this.events = {
            redrawEvent: new Event('cfd_redraw'),
            fillEvent: new Event('cfd_fill'),
            mouseUpEvent: new Event('cfd_mouseup'),
            mouseDownEvent: new Event('cfd_mousedown'),
            mouseEnterEvent: new Event('cfd_mouseenter'),
            mouseLeaveEvent: new Event('cfd_mouseleave'),
            touchStartEvent: new Event('cfd_touchstart'),
            touchEndEvent: new Event('cfd_touchend'),
        };
        this.bindings = {
            mouseDown: this.mouseDown.bind(this),
            mouseMove: this.mouseMove.bind(this),
            mouseLeave: this.mouseLeave.bind(this),
            mouseUp: this.mouseUp.bind(this),
            mouseUpDocument: this.mouseUpDocument.bind(this),
            touchStart: this.touchStart.bind(this),
            touchMove: this.touchMove.bind(this),
            touchEnd: this.touchEnd.bind(this),
        };
        this.touchIdentifier = undefined;
        this.previousX = undefined;
        this.previousY = undefined;
        this.showWarnings = showWarnings;
        // cache
        this.isNodeColorEqualCache = {};
        this.setDimensions();
        this.setBackground(backgroundColor);
        this.storeSnapshot();
        if (!disabled)
            this.enableDrawingMode();
    }
    requiredParam(object, param) {
        if (!object || !object[param]) {
            throw new Error(`${param} is required`);
        }
    }
    logWarning(...args) {
        if (this.showWarnings)
            console.warn(...args);
    }
    addListeners() {
        this.listenersList.forEach(event => {
            this.canvas.addEventListener(event.toLowerCase(), this.bindings[event]);
        });
        document.addEventListener('mouseup', this.bindings.mouseUpDocument);
    }
    removeListeners() {
        this.listenersList.forEach(event => {
            this.canvas.removeEventListener(event.toLowerCase(), this.bindings[event]);
        });
        document.removeEventListener('mouseup', this.bindings.mouseUpDocument);
    }
    getAllowedEvents() {
        const events = [];
        for (const event in AllowedEvents) {
            events.push(event);
        }
        return events;
    }
    enableDrawingMode() {
        this.isDrawingModeEnabled = true;
        this.addListeners();
        this.toggleCursor();
        return this.isDrawingModeEnabled;
    }
    disableDrawingMode() {
        this.isDrawingModeEnabled = false;
        this.removeListeners();
        this.toggleCursor();
        return this.isDrawingModeEnabled;
    }
    mouseDown(event) {
        if (event.button !== 0)
            return;
        const x = event.pageX - this.canvas.offsetLeft;
        const y = event.pageY - this.canvas.offsetTop;
        this.drawPoint(x, y);
    }
    mouseMove(event) {
        const x = event.pageX - this.canvas.offsetLeft;
        const y = event.pageY - this.canvas.offsetTop;
        this.drawLine(x, y, event);
    }
    touchStart(event) {
        if (event.changedTouches.length > 0) {
            const { pageX, pageY, identifier } = event.changedTouches[0];
            const x = pageX - this.canvas.offsetLeft;
            const y = pageY - this.canvas.offsetTop;
            this.touchIdentifier = identifier;
            this.drawPoint(x, y);
        }
    }
    touchMove(event) {
        if (event.changedTouches.length > 0) {
            const { pageX, pageY, identifier } = event.changedTouches[0];
            const x = pageX - this.canvas.offsetLeft;
            const y = pageY - this.canvas.offsetTop;
            // check if is multi touch, if it is do nothing
            if (identifier != this.touchIdentifier)
                return;
            this.previousX = x;
            this.previousY = y;
            this.drawLine(x, y, event);
        }
    }
    touchEnd() {
        this.handleEndDrawing();
        this.canvas.dispatchEvent(this.events.touchEndEvent);
    }
    mouseUp() {
        this.handleEndDrawing();
        this.canvas.dispatchEvent(this.events.mouseUpEvent);
    }
    mouseUpDocument() {
        this.leftCanvasDrawing = false;
    }
    mouseLeave() {
        if (this.isDrawing)
            this.leftCanvasDrawing = true;
        this.isDrawing = false;
        this.canvas.dispatchEvent(this.events.mouseLeaveEvent);
    }
    mouseEnter() {
        this.canvas.dispatchEvent(this.events.mouseEnterEvent);
    }
    handleEndDrawing() {
        this.isDrawing = false;
        this.storeSnapshot();
    }
    drawPoint(x, y) {
        if (this.isBucketToolEnabled) {
            this.fill(x, y, this.bucketToolColor, {
                tolerance: this.bucketToolTolerance,
            });
        }
        else {
            this.isDrawing = true;
            this.storeDrawing(x, y, false);
            this.canvas.dispatchEvent(this.events.mouseDownEvent);
            this.handleDrawing();
        }
    }
    drawLine(x, y, event) {
        if (this.leftCanvasDrawing) {
            this.leftCanvasDrawing = false;
            if (event instanceof MouseEvent) {
                this.mouseDown(event);
            }
            else if (event instanceof TouchEvent) {
                this.touchEnd();
            }
        }
        if (this.isDrawing) {
            this.storeDrawing(x, y, true);
            this.handleDrawing(this.dispatchEventsOnceEvery);
        }
    }
    handleDrawing(dispatchEventsOnceEvery) {
        this.context.lineJoin = 'round';
        const positions = [[...this.positions].pop()];
        positions.forEach(position => {
            if (position && position[0] && position[0].strokeColor) {
                this.context.strokeStyle = this.rgbaFromArray(position[0].strokeColor);
                this.context.lineWidth = position[0].lineWidth;
                this.draw(position);
            }
        });
        if (!dispatchEventsOnceEvery) {
            this.canvas.dispatchEvent(this.events.redrawEvent);
        }
        else if (this.redrawCounter % dispatchEventsOnceEvery === 0) {
            this.canvas.dispatchEvent(this.events.redrawEvent);
        }
        this.undos = [];
        this.redrawCounter += 1;
    }
    draw(position) {
        position.forEach(({ x, y, moving }, i) => {
            this.context.beginPath();
            if (moving && i) {
                this.context.moveTo(position[i - 1]['x'], position[i - 1]['y']);
            }
            else {
                this.context.moveTo(x - 1, y);
            }
            this.context.lineTo(x, y);
            this.context.closePath();
            this.context.stroke();
        });
    }
    // https://en.wikipedia.org/wiki/Flood_fill
    fill(x, y, newColor, { tolerance }) {
        newColor = this.toValidColor(newColor);
        if (this.positions.length === 0 && !this.imageRestored) {
            this.setBackground(newColor, false);
            this.canvas.dispatchEvent(this.events.redrawEvent);
            this.canvas.dispatchEvent(this.events.fillEvent);
            return;
        }
        const pixels = this.width * this.height;
        const imageData = this.context.getImageData(0, 0, this.width, this.height);
        const newData = imageData.data;
        const targetColor = this.getNodeColor(x, y, newData);
        if (this.isNodeColorEqual(targetColor, newColor, tolerance))
            return;
        const queue = [];
        queue.push([x, y]);
        while (queue.length) {
            if (queue.length > pixels)
                break;
            const n = queue.pop();
            let w = n;
            let e = n;
            while (this.isNodeColorEqual(this.getNodeColor(w[0] - 1, w[1], newData), targetColor, tolerance)) {
                w = [w[0] - 1, w[1]];
            }
            while (this.isNodeColorEqual(this.getNodeColor(e[0] + 1, e[1], newData), targetColor, tolerance)) {
                e = [e[0] + 1, e[1]];
            }
            const firstNode = w[0];
            const lastNode = e[0];
            for (let i = firstNode; i <= lastNode; i++) {
                this.setNodeColor(i, w[1], newColor, newData);
                if (this.isNodeColorEqual(this.getNodeColor(i, w[1] + 1, newData), targetColor, tolerance)) {
                    queue.push([i, w[1] + 1]);
                }
                if (this.isNodeColorEqual(this.getNodeColor(i, w[1] - 1, newData), targetColor, tolerance)) {
                    queue.push([i, w[1] - 1]);
                }
            }
        }
        this.context.putImageData(imageData, 0, 0);
        this.canvas.dispatchEvent(this.events.redrawEvent);
        this.canvas.dispatchEvent(this.events.fillEvent);
    }
    toValidColor(color) {
        if (Array.isArray(color) && color.length === 4)
            color.pop();
        if (Array.isArray(color) && color.length === 3) {
            const validColor = [...color];
            validColor.push(255);
            return validColor;
        }
        else {
            this.logWarning('Color is not valid!\n' +
                'It must be an array with RGB values:  [0-255, 0-255, 0-255]');
            return [0, 0, 0, 255];
        }
    }
    // i = color 1; j = color 2; t = tolerance
    isNodeColorEqual(i, j, t) {
        const color1 = '' + i[0] + i[1] + i[2] + i[3];
        const color2 = '' + j[0] + j[1] + j[2] + j[3];
        const key = color1 + color2 + t;
        t = t || 0;
        if (this.isNodeColorEqualCache.hasOwnProperty(color1 + color2 + t)) {
            return this.isNodeColorEqualCache[key];
        }
        const diffRed = Math.abs(j[0] - i[0]);
        const diffGreen = Math.abs(j[1] - i[1]);
        const diffBlue = Math.abs(j[2] - i[2]);
        const percentDiffRed = diffRed / 255;
        const percentDiffGreen = diffGreen / 255;
        const percentDiffBlue = diffBlue / 255;
        const percentDiff = ((percentDiffRed + percentDiffGreen + percentDiffBlue) / 3) * 100;
        const result = t >= percentDiff;
        this.isNodeColorEqualCache[key] = result;
        return result;
    }
    getNodeColor(x, y, data) {
        const i = (x + y * this.width) * 4;
        return [data[i], data[i + 1], data[i + 2], data[i + 3]];
    }
    setNodeColor(x, y, color, data) {
        const i = (x + y * this.width) * 4;
        data[i] = color[0];
        data[i + 1] = color[1];
        data[i + 2] = color[2];
        data[i + 3] = color[3];
    }
    rgbaFromArray(a) {
        return `rgba(${a[0]},${a[1]},${a[2]},${a[3]})`;
    }
    setDimensions() {
        this.canvas.height = this.height;
        this.canvas.width = this.width;
    }
    toggleCursor() {
        this.canvas.style.cursor = this.isDrawingModeEnabled ? 'crosshair' : 'auto';
    }
    storeDrawing(x, y, moving) {
        if (moving) {
            const lastIndex = this.positions.length - 1;
            this.positions[lastIndex].push({
                x,
                y,
                moving,
                lineWidth: this.lineWidth,
                strokeColor: this.strokeColor,
                isBucket: false,
            });
        }
        else {
            this.positions.push([
                {
                    x,
                    y,
                    isBucket: false,
                    moving,
                    lineWidth: this.lineWidth,
                    strokeColor: this.strokeColor,
                },
            ]);
        }
    }
    storeSnapshot() {
        const imageData = this.getCanvasSnapshot();
        this.snapshots.push(imageData);
        if (this.snapshots.length > this.maxSnapshots) {
            this.snapshots = this.snapshots.splice(-Math.abs(this.maxSnapshots));
        }
    }
    getCanvasSnapshot() {
        return this.context.getImageData(0, 0, this.width, this.height);
    }
    restoreCanvasSnapshot(imageData) {
        this.context.putImageData(imageData, 0, 0);
    }
    // Public APIs
    on(params, callback) {
        const { event, counter } = params;
        this.requiredParam(params, 'event');
        if (this.allowedEvents.includes(event)) {
            if (event === 'redraw' && counter && Number.isInteger(counter)) {
                this.dispatchEventsOnceEvery = counter;
            }
            this.canvas.addEventListener('cfd_' + event, () => callback());
        }
        else {
            this.logWarning(`This event is not allowed: ${event}`);
        }
    }
    setLineWidth(px) {
        this.lineWidth = px;
    }
    setBackground(color, save = true) {
        const validColor = this.toValidColor(color);
        if (validColor) {
            if (save)
                this.backgroundColor = validColor;
            this.context.fillStyle = this.rgbaFromArray(validColor);
            this.context.fillRect(0, 0, this.width, this.height);
        }
    }
    setDrawingColor(color) {
        this.configBucketTool({ color });
        this.setStrokeColor(color);
    }
    setStrokeColor(color) {
        this.strokeColor = this.toValidColor(color);
    }
    configBucketTool(params) {
        const { color = null, tolerance = null } = params;
        if (color)
            this.bucketToolColor = this.toValidColor(color);
        if (tolerance && tolerance > 0) {
            this.bucketToolTolerance = tolerance > 100 ? 100 : tolerance;
        }
    }
    toggleBucketTool() {
        return (this.isBucketToolEnabled = !this.isBucketToolEnabled);
    }
    toggleDrawingMode() {
        return this.isDrawingModeEnabled
            ? this.disableDrawingMode()
            : this.enableDrawingMode();
    }
    clear() {
        this.context.clearRect(0, 0, this.width, this.height);
        this.positions = [];
        this.imageRestored = false;
        if (this.backgroundColor)
            this.setBackground(this.backgroundColor);
        this.handleEndDrawing();
    }
    save() {
        return this.canvas.toDataURL();
    }
    restore(backup, callback) {
        const image = new Image();
        image.src = backup;
        image.onload = () => {
            this.imageRestored = true;
            this.context.drawImage(image, 0, 0);
            if (typeof callback === 'function')
                callback();
        };
    }
    undo() {
        const lastSnapshot = this.snapshots[this.snapshots.length - 1];
        const goToSnapshot = this.snapshots[this.snapshots.length - 2];
        if (goToSnapshot) {
            this.restoreCanvasSnapshot(goToSnapshot);
            this.snapshots.pop();
            this.undos.push(lastSnapshot);
            this.undos = this.undos.splice(-Math.abs(this.maxSnapshots));
            this.imageRestored = true;
        }
        else {
            this.logWarning('There are no more undos left.');
        }
    }
    redo() {
        if (this.undos.length > 0) {
            const lastUndo = this.undos.pop();
            if (lastUndo) {
                this.restoreCanvasSnapshot(lastUndo);
                this.snapshots.push(lastUndo);
                this.snapshots = this.snapshots.splice(-Math.abs(this.maxSnapshots));
            }
        }
        else {
            this.logWarning('There are no more redo left.');
        }
    }
}
exports.default = freeDrawing;

},{}],3:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Utility {
    static hex2RGB(color) {
        // 16进制颜色值的正则
        var reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
        // 把颜色值变成小写
        color = color.toLowerCase();
        if (reg.test(color)) {
            // 如果只有三位的值，需变成六位，如：#fff => #ffffff
            if (color.length === 4) {
                var colorNew = "#";
                for (var i = 1; i < 4; i += 1) {
                    colorNew += color.slice(i, i + 1).concat(color.slice(i, i + 1));
                }
                color = colorNew;
            }
            // 处理六位的颜色值，转为RGB
            var colorChange = [];
            for (var i = 1; i < 7; i += 2) {
                colorChange.push(parseInt("0x" + color.slice(i, i + 2)));
            }
            return colorChange;
        }
        else {
            throw new Error('color is unvalid');
        }
    }
}
Utility.doLastError = () => {
    var res = true;
    if (chrome.runtime.lastError) {
        res = false;
        chrome.browserAction.setPopup({ popup: 'popup.html' });
    }
    return res;
};
exports.Utility = Utility;

},{}]},{},[1]);
